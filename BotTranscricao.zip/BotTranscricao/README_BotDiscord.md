# Bot de Transcrição para Discord

Este bot permite gravar áudio de canais de voz do Discord e salvar em arquivos .wav. Ele utiliza o FFmpeg para capturar o áudio do sistema enquanto você está em um canal de voz do Discord.

## Requisitos

- Python 3.8 ou superior
- Token de bot do Discord
- FFmpeg instalado e disponível no PATH do sistema
- Pelo menos um dispositivo de áudio disponível no sistema

## Instalação

1. Clone este repositório ou baixe os arquivos
2. Instale as dependências:

```bash
pip install -r requirements.txt
```

3. Configure o arquivo `.env` com seu token do Discord:

```
DISCORD_TOKEN=seu_token_aqui
```

4. Certifique-se de que o FFmpeg está instalado e disponível no PATH do sistema

### Comandos disponíveis

- `!entrar` - Conecta o bot ao seu canal de voz atual
- `!gravar` - Inicia a gravação do áudio no canal
- `!parar` - Para a gravação e salva o arquivo de áudio
- `!sair` - Desconecta o bot do canal de voz
- `!listar` - Lista todos os arquivos de gravação disponíveis

## Como funciona

O bot se conecta ao canal de voz do Discord e utiliza o FFmpeg para gravar o áudio que está sendo reproduzido no seu sistema. Isso permite capturar tanto o áudio do Discord quanto qualquer outro som que esteja sendo reproduzido.

O áudio é gravado com as seguintes configurações:
- 2 canais (estéreo)
- 16 bits por amostra
- Taxa de amostragem de 44.1kHz

### Configurando o dispositivo de áudio para gravação

Opções de dispositivos de áudio para gravação:

1. **Stereo Mix** (se disponível no seu sistema):
   - Clique com o botão direito no ícone de som na barra de tarefas
   - Selecione "Sons" ou "Configurações de som"
   - Vá para a aba "Gravação"
   - Clique com o botão direito em uma área vazia e selecione "Mostrar dispositivos desativados"
   - Localize "Stereo Mix", clique com o botão direito e selecione "Habilitar"

## Solução de problemas

Se encontrar problemas com a gravação de áudio:

1. Verifique se o FFmpeg está instalado corretamente e disponível no PATH do sistema
2. Certifique-se de que o dispositivo de áudio virtual está configurado e funcionando
3. Verifique se o bot tem as permissões necessárias no Discord (precisa de permissões para conectar e falar em canais de voz)
4. Se o áudio gravado estiver vazio ou com baixa qualidade:
   - Verifique se o volume do Discord está adequado
   - Certifique-se de que o dispositivo de áudio está capturando o som corretamente
   - Teste diferentes configurações de áudio no Windows

### Detecção automática de dispositivos de áudio

O bot agora segue uma ordem de prioridade para selecionar o dispositivo de áudio para gravação:

1. Primeiro tenta usar o microfone Fifine ("Microfone (2- Fifine Microphone)") ou seu identificador alternativo se estiver disponível
2. Se não encontrar, tenta usar o dispositivo de áudio padrão do sistema (o mesmo que o Discord utiliza para saída de áudio)
3. Se não conseguir detectar o dispositivo padrão, tenta usar o Voicemod Virtual Audio Device
4. Por último, usa o primeiro dispositivo de áudio disponível no sistema

O bot agora também suporta o uso do identificador alternativo do dispositivo Fifine (`@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\wave_{A19A230B-EE1D-48B0-BB7F-D7F94E1AE7CA}`), o que pode resolver problemas de compatibilidade em alguns sistemas.

Não é necessário configurar manualmente o dispositivo de áudio no código, mas você pode verificar quais dispositivos estão disponíveis executando o script:

```
python listar_dispositivos.py
```

### Modificando o dispositivo de áudio manualmente (opcional)

Se você preferir especificar um dispositivo de áudio específico em vez de usar a detecção automática, você pode modificar o código:

1. Execute o script `listar_dispositivos.py` para ver todos os dispositivos de áudio disponíveis para o FFmpeg:
   ```
   python listar_dispositivos.py
   ```

2. Abra o arquivo `main.py` e localize a função `get_first_audio_device()`

3. Modifique a função para retornar o nome do dispositivo específico que você deseja usar:
   ```python
   def get_first_audio_device():
       return "SEU_DISPOSITIVO_AQUI"  # Substitua pelo nome exato do dispositivo
   ```

4. Reinicie o bot para aplicar as alterações