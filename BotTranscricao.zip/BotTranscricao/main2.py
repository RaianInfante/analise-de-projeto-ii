# Importações necessárias
import discord
from discord.ext import commands
import os
import subprocess
import asyncio
import time
import datetime
import re
from dotenv import load_dotenv

# ==============================================
# TENTATIVA DE IMPORTAR A BIBLIOTECA PYCAW
# ==============================================
# Essa biblioteca é usada para detectar o dispositivo de áudio padrão do Windows.
# Caso não esteja instalada, o bot utilizará um método alternativo.
try:
    from pycaw.pycaw import AudioUtilities
    PYCAW_AVAILABLE = True
except ImportError:
    print("Biblioteca pycaw não encontrada. Usando método alternativo para detecção de dispositivos de áudio.")
    PYCAW_AVAILABLE = False

# ==============================================
# CARREGAR VARIÁVEIS DE AMBIENTE
# ==============================================
# O arquivo .env deve conter informações sensíveis, como o DISCORD_TOKEN.
load_dotenv()

# ==============================================
# CONFIGURAÇÃO DO BOT
# ==============================================
intents = discord.Intents.default()
intents.message_content = True      # Permite o bot ler mensagens
# Permite o bot monitorar estados em canais de voz
intents.voice_states = True
bot = commands.Bot(command_prefix="!", intents=intents)

# ==============================================
# CRIAR PASTA PARA SALVAR GRAVAÇÕES
# ==============================================
if not os.path.exists("audios"):
    os.makedirs("audios")

# Dicionário que armazena os processos de gravação ativos por servidor
# Estrutura: { guild_id: { process, filename, start_time, audio_device } }
recording_data = {}

# ==============================================
# EVENTO: QUANDO O BOT FICA ONLINE
# ==============================================


@bot.event
async def on_ready():
    print(f"Bot conectado como {bot.user}")


# ==============================================
# COMANDO: ENTRAR EM UM CANAL DE VOZ
# ==============================================
@bot.command()
async def entrar(ctx):
    """
    Faz o bot entrar no mesmo canal de voz do usuário que digitou o comando.
    Caso já esteja conectado, apenas muda para o novo canal.
    """
    if ctx.author.voice:  # Verifica se o usuário está em um canal de voz
        channel = ctx.author.voice.channel
        if ctx.voice_client is not None:
            await ctx.voice_client.move_to(channel)
        else:
            await channel.connect()
        await ctx.send(f"Conectado ao canal {channel.name}")
    else:
        await ctx.send("Você não está em um canal de voz!")


# ==============================================
# FUNÇÃO: OBTÉM O DISPOSITIVO DE ÁUDIO PADRÃO
# ==============================================
def get_default_audio_device():
    """
    Obtém o dispositivo de áudio padrão do sistema.
    - Tenta primeiro identificar especificamente o microfone Fifine.
    - Se não encontrar, usa a biblioteca pycaw para pegar o dispositivo padrão.
    """
    try:
        # Usa o FFmpeg para listar dispositivos de áudio disponíveis
        result = subprocess.run(
            ["ffmpeg", "-hide_banner", "-list_devices",
                "true", "-f", "dshow", "-i", "dummy"],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace'
        )

        # Busca por dispositivos específicos (como o microfone Fifine)
        if "Microfone (2- Fifine Microphone)" in result.stderr:
            print("Usando Microfone (2- Fifine Microphone) como dispositivo de gravação")
            return "Microfone (2- Fifine Microphone)"
        elif "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\\wave_{A19A230B-EE1D-48B0-BB7F-D7F94E1AE7CA}" in result.stderr:
            print(
                "Usando nome alternativo do Fifine Microphone como dispositivo de gravação")
            return "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\\wave_{A19A230B-EE1D-48B0-BB7F-D7F94E1AE7CA}"
    except Exception as e:
        print(f"Erro ao verificar microfone Fifine: {e}")

    # Caso não encontre o Fifine, tenta usar a biblioteca pycaw
    try:
        if PYCAW_AVAILABLE:
            speakers = AudioUtilities.GetSpeakers()
            if speakers:
                device_name = speakers.FriendlyName
                print(f"Dispositivo de áudio padrão detectado: {device_name}")
                return device_name
    except Exception as e:
        print(f"Erro ao obter dispositivo de áudio padrão com pycaw: {e}")

    return None


# ==============================================
# FUNÇÃO: OBTÉM O PRIMEIRO DISPOSITIVO DE ÁUDIO DISPONÍVEL
# ==============================================
def get_first_audio_device():
    """
    Retorna o primeiro dispositivo de áudio encontrado.
    - Primeiro tenta pegar o dispositivo padrão do sistema.
    - Caso não consiga, lista dispositivos usando FFmpeg ou PowerShell.
    """
    try:
        # Primeira tentativa: dispositivo padrão
        default_device = get_default_audio_device()
        if default_device:
            return default_device

        # Segunda tentativa: listar dispositivos com FFmpeg
        result = subprocess.run(
            ["ffmpeg", "-hide_banner", "-list_devices",
                "true", "-f", "dshow", "-i", "dummy"],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace'
        )

        output = result.stderr
        audio_devices = []
        audio_section = False

        # Varre a saída do FFmpeg em busca de dispositivos de áudio
        for line in output.split('\n'):
            if "DirectShow audio devices" in line:
                audio_section = True
                continue
            if audio_section and "DirectShow video devices" in line:
                audio_section = False
                break

            if audio_section:
                match = re.search(r'"([^"]+)"', line)
                if match:
                    audio_devices.append(match.group(1))

        # Terceira tentativa: listar via PowerShell (Windows)
        if not audio_devices:
            ps_cmd = "Get-WmiObject Win32_SoundDevice | Select-Object -ExpandProperty Name"
            ps_result = subprocess.run(
                ["powershell", "-Command", ps_cmd],
                capture_output=True,
                text=True
            )

            if ps_result.returncode == 0:
                audio_devices = [device.strip() for device in ps_result.stdout.split(
                    '\n') if device.strip()]

        return audio_devices[0] if audio_devices else None

    except Exception as e:
        print(f"Erro ao listar dispositivos: {e}")
        return None


# ==============================================
# COMANDO: INICIAR GRAVAÇÃO DE ÁUDIO
# ==============================================
@bot.command()
async def gravar(ctx):
    """
    Inicia a gravação de áudio no canal de voz.
    O áudio é capturado do dispositivo configurado no sistema.
    """
    if not ctx.voice_client:
        await ctx.send("O bot não está conectado a nenhum canal de voz. Use !entrar primeiro.")
        return

    guild_id = ctx.guild.id

    # Impede múltiplas gravações simultâneas no mesmo servidor
    if guild_id in recording_data:
        await ctx.send("Já existe uma gravação em andamento neste servidor.")
        return

    # Cria nome do arquivo com data e hora
    timestamp = int(time.time())
    date_str = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"audios/gravacao_{guild_id}_{date_str}.wav"

    # Obtém dispositivo de áudio
    audio_device = get_default_audio_device() or get_first_audio_device()

    if not audio_device:
        await ctx.send("Não foi possível encontrar nenhum dispositivo de áudio. Verifique se há dispositivos disponíveis.")
        return

    try:
        # Comando para iniciar gravação com FFmpeg
        process = subprocess.Popen([
            "ffmpeg",
            "-f", "dshow",
            "-i", f"audio={audio_device}",
            "-acodec", "pcm_s16le",
            "-ar", "44100",
            "-ac", "2",
            filename
        ], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Armazena informações da gravação
        recording_data[guild_id] = {
            "process": process,
            "filename": filename,
            "start_time": timestamp,
            "audio_device": audio_device
        }

        await ctx.send(f"Gravação iniciada! Use !parar para finalizar.\n\nDispositivo em uso: '{audio_device}'")

    except Exception as e:
        await ctx.send(f"Erro ao iniciar gravação: {str(e)}\nVerifique se o dispositivo '{audio_device}' está disponível.")


# ==============================================
# COMANDO: PARAR GRAVAÇÃO DE ÁUDIO
# ==============================================
@bot.command()
async def parar(ctx):
    """
    Finaliza a gravação e salva o arquivo .wav na pasta 'audios'.
    Também cria um arquivo .txt com informações da gravação.
    """
    guild_id = ctx.guild.id

    if guild_id not in recording_data:
        await ctx.send("Não há gravação em andamento neste servidor.")
        return

    try:
        rec_data = recording_data[guild_id]
        process = rec_data["process"]
        filename = rec_data["filename"]

        # Encerra o processo do FFmpeg enviando 'q'
        process.communicate(input=b'q')
        process.terminate()

        # Calcula a duração da gravação
        duration = time.time() - rec_data["start_time"]
        duration_str = f"{int(duration // 60)}m {int(duration % 60)}s"

        # Verifica se o arquivo foi criado corretamente
        if os.path.exists(filename) and os.path.getsize(filename) > 0:
            # Cria arquivo de texto com informações adicionais
            txt_filename = filename.replace(".wav", ".txt")
            try:
                with open(txt_filename, "w") as f:
                    f.write(
                        f"Áudio gravado\nDuração: {duration_str}\n"
                        f"Dispositivo: {rec_data.get('audio_device', 'Desconhecido')}\n"
                        f"Data: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    )
            except Exception as write_error:
                print(
                    f"Erro ao salvar informações adicionais: {str(write_error)}")

            await ctx.send(f"Gravação finalizada! Duração: {duration_str}\nArquivo salvo como: {filename}")
        else:
            await ctx.send(f"Aviso: O arquivo parece estar vazio ou não foi criado corretamente.\nVerifique o dispositivo '{rec_data.get('audio_device', 'Desconhecido')}'.")

        # Remove informações do dicionário
        del recording_data[guild_id]

    except Exception as e:
        await ctx.send(f"Erro ao parar gravação: {str(e)}")


# ==============================================
# COMANDO: SAIR DO CANAL DE VOZ
# ==============================================
@bot.command()
async def sair(ctx):
    """
    Faz o bot sair do canal de voz.
    Caso haja uma gravação em andamento, ela será finalizada antes.
    """
    guild_id = ctx.guild.id

    # Finaliza gravação ativa antes de sair
    if guild_id in recording_data:
        try:
            rec_data = recording_data[guild_id]
            process = rec_data["process"]
            process.communicate(input=b'q')
            process.terminate()
            del recording_data[guild_id]
        except Exception as e:
            await ctx.send(f"Erro ao finalizar gravação: {str(e)}")

    if ctx.voice_client:
        await ctx.voice_client.disconnect()
        await ctx.send("Desconectado do canal de voz.")
    else:
        await ctx.send("O bot não está conectado a nenhum canal de voz.")


# ==============================================
# COMANDO: LISTAR ARQUIVOS DE GRAVAÇÃO
# ==============================================
@bot.command()
async def listar(ctx):
    """
    Lista todos os arquivos de gravação presentes na pasta 'audios'.
    """
    files = os.listdir("audios")
    if files:
        file_list = "\n".join(files)
        await ctx.send(f"Arquivos disponíveis:\n```{file_list}```")
    else:
        await ctx.send("Não há arquivos de gravação disponíveis.")


# ==============================================
# INICIALIZAÇÃO DO BOT
# ==============================================
# Token armazenado no arquivo .env
bot.run(os.getenv("DISCORD_TOKEN"))
